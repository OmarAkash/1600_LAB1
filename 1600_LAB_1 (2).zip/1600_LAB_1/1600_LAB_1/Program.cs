﻿//*********************************************************************
//Program: LAB 1
//Author: Md Omar Faruq Akash
//Class: CMPE1600
//Instructor: Kevin Moore
//*********************************************************************

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;               // to use GDIDrawer
using GDIDrawer;                    // to use GDIDrawer
using System.IO;                    // to use class streamreader and streamwriter

namespace lab1_1600
{
    class Program
    {
        static void Main(string[] args)
        {
            string selection;
            int size;
            int[] randomNum = new int[10000];
            do
            {
                Console.WriteLine();
                Console.WriteLine();
                Console.WriteLine("\t\t\t\tLab 4 - Array of Marks");
                Console.Write("\nActions available...");
                Console.WriteLine("\n1. Create Random array...");
                Console.WriteLine("2. Array Stats");
                Console.WriteLine("3. Draw Histogram");
                Console.WriteLine("4. Save array to file");
                Console.WriteLine("5. Load array from file");
                Console.WriteLine("q. Exit the program");
                Console.Write("\nYour selection: ");
                selection = Console.ReadLine().ToString();


                

                switch (selection)
                {
                    case "1":
                        {
                            GetArray(out size, "\nEnter the size of array: ", 1, 10000);
                            randomNum = MakeArray(size);
                            DisplayArray(randomNum);

                            break;

                        }
                    case "2":
                        {
                            if (randomNum[0] == 0 || randomNum.Length - 1 == 0)
                            {
                                Console.Beep();
                                Console.WriteLine("\nError no array yet!");
                                break;
                            }
                            DisplayArraySorted(randomNum);
                            Console.WriteLine("\n\nPress any key to continue....");
                            break;

                        }
                    case "3":
                        {
                            if (randomNum[0] == 0 || randomNum.Length - 1 == 0)
                            {
                                Console.Beep();
                                Console.WriteLine("\nError no array yet!");
                                break;
                            }
                            DrawHistogram(randomNum);
                            Console.WriteLine("\n\nPress any key to continue....");
                            break;
                        }
                    case "4":
                        {
                            if (randomNum[0] == 0 || randomNum.Length - 1 == 0)
                            {
                                Console.Beep();
                                Console.WriteLine("\nError no array yet!");
                                break;
                            }
                            SaveFile(randomNum);
                            Console.WriteLine("\n\nPress any key to continue....");
                            break;
                        }
                    case "5":
                        {
                            LoadFile(randomNum);
                            Console.WriteLine("\n\nPress any key to continue....");
                            break;
                        }


                }



            } while (selection != "q");
        }

        static int GetArray(out int size, string prompt, int minimum, int maximum)
        {
            bool success;
            do
            {
                Console.Write(prompt);
                success = int.TryParse(Console.ReadLine(), out size);
                if (!success || size < minimum || size > maximum)
                {
                    if (!success)
                    {
                        Console.WriteLine("An invalid value was entered. Please try again");
                    }
                    else if (size < minimum || size > maximum)
                    {
                        Console.WriteLine("the value is out of range. Please enter i value from 1 to 10000");
                    }
                }
            } while (!success || size < minimum || size > maximum);
            return size;
        }
        static int[] MakeArray(int size)
        {
            int[] arrays = new int[size];
            Random rand = new Random();
            for (int i = 0; i < arrays.Length; ++i)
            {
                arrays[i] = rand.Next(0, 101);

            }
            return arrays;
        }
        static private void DisplayArray(int[] randomNum)
        {

            Console.WriteLine("\nThe current contents for the array: \n");
            for (int i = 0; i < randomNum.Length; i++)
            {
                Console.Write($" {randomNum.GetValue(i)}");
            }

        }
        static private void DisplayArraySorted(int[] randomNum)
        {
            Array.Sort(randomNum);
            Console.WriteLine("\nthe array has been sorted");
            Console.WriteLine("\nThe current contents for the array: \n");
            for (int i = 0; i < randomNum.Length; i++)
            {
                Console.Write($" {randomNum.GetValue(i)}");
            }
            Console.WriteLine($"\n\nThe minimum value is {randomNum.Min()}.");
            Console.WriteLine($"The average value is {randomNum.Average():F2}");
            Console.WriteLine($"The maximum value is {randomNum.Max()}");
        }
        static void DrawHistogram(int[] randomNum)
        {
            int A = 0;  // ranging from 0-9
            int B = 0;  // ranging from 10-19            
            int C = 0;  // ranging from 21-29
            int D = 0;  // ranging from 30-39
            int E = 0;  // ranging from 40-49
            int F = 0;  // ranging from 50-59
            int G = 0;  // ranging from 60-69
            int H = 0;  // ranging from 70-79
            int I = 0;  // ranging from 80-89
            int J = 0;  // ranging from 90-99
            int K = 0;  // 100

            // using the 800x600 drawer window, leaving 20 pixels on the bottom to show the ranges

            CDrawer canvas = new CDrawer(800, 600);

            // Sets up the range for histogram. Checks which group the element in the array belongs 
            // to and then places it in its respective group.

            foreach (int value in randomNum)
            {
                if (value < 10)
                {
                    A++;
                }
                if (value > 9 && value < 20)
                {
                    B++;
                }
                if (value > 19 && value < 30)
                {
                    C++;
                }
                if (value > 29 && value < 40)
                {
                    D++;
                }
                if (value > 39 && value < 50)
                {
                    E++;
                }
                if (value > 49 && value < 60)
                {
                    F++;
                }
                if (value > 59 && value < 70)
                {
                    G++;
                }
                if (value > 69 && value < 80)
                {
                    H++;
                }
                if (value > 79 && value < 90)
                {
                    I++;
                }
                if (value > 89 && value < 100)
                {
                    J++;
                }
                if (value == 100)
                {
                    K++;
                }
            }

            // Sets up colour to each histogram bar

            int[] _histogramArray = { A, B, C, D, E, F, G, H, I, J, K };
            string[] labelArray = { "0-9", "10-19", "20-29", "30-39", "40-49", "50-59", "60-69", "70-79", "80-89", "90-99", "100" };
            Color[] colorArray = { Color.Red, Color.Green, Color.Blue, Color.Cyan, Color.Magenta, Color.Yellow, Color.Orange,
                Color.Pink, Color.Brown, Color.White, Color.DarkViolet };

            int scale = 580 / _histogramArray.Max();
            canvas.Clear();
            for (int i = 0; i < _histogramArray.Length; i++)
            {
                if (_histogramArray[i] != 0)
                {
                    canvas.AddRectangle(i * 72, 580 - _histogramArray[i] * scale, 72, _histogramArray[i] * scale, colorArray[i]);
                    canvas.AddText(_histogramArray[i].ToString(), 16, i * 72, (580 - _histogramArray[i] * scale) + (_histogramArray[i] * scale) / 2 - 18, 72, 40, Color.Black);
                    canvas.AddText(labelArray[i], 12, i * 72, 580, 72, 20, Color.Wheat);

                }
                else
                {
                    canvas.AddText(labelArray[i], 12, i * 72, 580, 72, 20, Color.Wheat);
                }

            }
        }

        // using class StreamWriter to save and StreamReader to load file.

        static void SaveFile(int[] randomNum)
        {
            Console.Write("\nEnter the name of the save file: ");
            string File = Console.ReadLine();
            StreamWriter swSaveFile = new StreamWriter(File);
            for (int i = 0; i < randomNum.Length; i++)
            {
                swSaveFile.Write($"{randomNum.GetValue(i)} ");
            }
            swSaveFile.Close();
            Console.WriteLine($"\n{randomNum.Length} values saved to file {File}.");
        }
        static void LoadFile(int[] randomNum)
        {
            Console.Write("\nEnter the name of the file to be loaded: ");
            string File = (Console.ReadLine());
            StreamReader _openFile = new StreamReader(File);
            try
            {
                File = _openFile.ReadToEnd();
                Console.WriteLine();
                Console.WriteLine(File);

            }
            catch (Exception e)
            {
                Console.WriteLine($"Error reading file: {e.Message}");
            }
            finally
            {
                _openFile.Close();

            }
        }
    }
}
